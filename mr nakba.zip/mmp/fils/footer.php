<footer>
   	<div class="zamal_1">
   		<a href="#"><?php echo $wiz_114 ; ?></a>
   		<a href="#"><?php echo $wiz_115 ; ?></a>
   	</div>
   	<div class="zamal_2">
   		<ul>
   			<li>
   				<span>©1999 -2016 PayPal. <?php echo $wiz_116 ; ?></span>
   			</li>
   			<li>
   				<a href="#"><?php echo $wiz_117 ; ?></a>
   			</li>
   			<li>
   				<a href="#"><?php echo $wiz_118 ; ?></a>
   			</li>
   			<li>
   				<a href="#"><?php echo $wiz_119 ; ?></a>
   			</li>
   		</ul>
   	</div>
   </footer>