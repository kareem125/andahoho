<!-- Start Nav Desktop -->

  <div class="nav_wiz">
  	<div class="lwast">
  		<a href="#" class="logo_moustache">
  			<img src="img/ll.svg">
  		</a>
  		<ul class="hassan">
  			<li>
  				<a href="#"><?php echo $wiz_101 ; ?></a>
  			</li>
  			<li>
  				<a href="#"><?php echo $wiz_102 ; ?></a>
  			</li>
  			<li>
  				<a href="#"><?php echo $wiz_103 ; ?></a>
  			</li>
  			<li>
  				<a href="#"><?php echo $wiz_104 ; ?></a>
  			</li>
  			<li>
  				<a href="#"><?php echo $wiz_105 ; ?></a>
  			</li>
  		</ul>
  		<ul class="ana_moustache_kk">
  			<li>
  				<a href="#"></a>
  			</li>
  			<li>
  				<a href="#" class="zabi_la_khrajti"><?php echo $wiz_106 ; ?></a>
  			</li>
  		</ul>
  	</div>
  </div>

<!-- End Nav Desktop -->

<!-- Start Nav Mobile -->

<div class="nav_mobile">
	<div class="yadak_fih">
		<a href="#">
			<?php echo $wiz_107 ; ?>
		</a>
	</div>
	<div class="logo">
		<img src="img/ll.svg">
	</div>
</div>
<!-- End Nav Mobile -->

   <div class="nav_ta7t">
   	<ul class="amly_zamal_kk">
   		<li class="mote">
   			<a href="#"><?php echo $wiz_108 ; ?></a>
   		</li>
   		<li>
   			<a href="#"><?php echo $wiz_109 ; ?></a>
   		</li>
   		<li>
   			<a href="#"><?php echo $wiz_112 ; ?></a>
   		</li>
   		<li>
   			<a href="#"><?php echo $wiz_113 ; ?></a>
   		</li>
   	</ul>
   </div>