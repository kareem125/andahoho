<?php

$yourmail = 'kareemdizydros@gmail.com';
